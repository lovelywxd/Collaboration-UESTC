//
//  groupBuyViewController.h
//  MyBookRecycle
//
//  Created by 苏丽荣 on 16/6/17.
//  Copyright © 2016年 苏丽荣. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "baseViewController.h"

//@interface groupBuyViewController : baseViewController
@interface groupBuyViewController : UIViewController

@end
