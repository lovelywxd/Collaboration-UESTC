//
//  ActivitysViewController.m
//  MyBookRecycle
//
//  Created by 苏丽荣 on 16/6/23.
//  Copyright © 2016年 苏丽荣. All rights reserved.
//

#import "ActivitysViewController.h"
#import "SlideTabBarView.h"

@interface ActivitysViewController ()
@property (nonatomic,strong) SlideTabBarView* slideBarView;
@end

@implementation ActivitysViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    CGRect frame = [[UIScreen mainScreen] bounds];
    NSLog(@"main screen:%@",NSStringFromCGRect(frame));
    NSInteger lowerBarHeight =  self.tabBarController.tabBar.frame.size.height;
    NSInteger higherBarHeight =  self.navigationController.navigationBar.frame.size.height;
    NSInteger statusBarHeight = [[UIApplication sharedApplication] statusBarFrame].size.height;
    
    frame.origin.y = higherBarHeight + statusBarHeight;
    CGRect rootviewFrame = self.view.frame;
    NSLog(@"rootviewFrame:%@",NSStringFromCGRect(rootviewFrame));
    self.navigationController.navigationBar.hidden = YES;


    NSLog(@"statusBarHeight:%ld,lowerBarHeight:%ld,higherBarHeight:%ld",statusBarHeight,lowerBarHeight,higherBarHeight);
    frame.size.height -= (lowerBarHeight + frame.origin.y);
    NSLog(@"subviewFrame:%@",NSStringFromCGRect(frame));
    UIView *view = [[UIView alloc] initWithFrame:frame];
    [view setBackgroundColor:[UIColor blueColor]];
    
//    frame.size.height = 150;
    CGRect slideBarViewFrame = CGRectMake(10, 10, frame.size.width - 20, frame.size.height - 30);
    
    self.slideBarView = [[SlideTabBarView alloc] initWithFrame:slideBarViewFrame withDelegate:self];
     NSLog(@"slideBarViewFrame:%@",NSStringFromCGRect(slideBarViewFrame));
    
    [self.slideBarView setColor:[UIColor purpleColor] AtIndex:2];
    
    CGRect frame2 = CGRectMake(365, 40, 5, 494);
    UIView *view2 = [[UIView alloc] initWithFrame:frame2];
    [view2 setBackgroundColor:[UIColor greenColor]];
    
    CGRect frame3 = CGRectMake(0,0, 5,10);
    UIView *view3 = [[UIView alloc] initWithFrame:frame3];
    [view3 setBackgroundColor:[UIColor yellowColor]];
    
    CGRect frame4 = CGRectMake(0,10, 5,30);
    UIView *view4 = [[UIView alloc] initWithFrame:frame4];
    [view4 setBackgroundColor:[UIColor whiteColor]];
    
    [view addSubview:self.slideBarView];
    [view addSubview:view2];
    [view addSubview:view3];
    [view addSubview:view4];
    
    [self.view addSubview:view];
//    [self.view addSubview:self.self.slideBarView];
}

- (CGFloat) heightForTopBar
{
    return 30;
}
- (NSArray*) titlesForTapButton
{
    return [NSArray arrayWithObjects:@"全部", @"京东", @"当当", nil];
}

- (UITableView*) tableForPage:(NSInteger)page withFrame:(CGRect)frame {
    
    NSLog(@"tableForPage:%@",NSStringFromCGRect(frame));
    UITableView *tableView = [[UITableView alloc] initWithFrame:frame];
    return tableView;
    
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView atPage:(NSInteger)page{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section atPage:(NSInteger)page{
    return 2;
}

-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath atPage:(NSInteger)page
{
    return 30;
}

-(UITableViewCell *)tableView:tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath atPage:(NSInteger)page
{
    static NSString* cellId = @"CellID";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellId];
        cell.textLabel.text = [NSString stringWithFormat:@"%ld",page];
        cell.detailTextLabel.text = [NSString stringWithFormat:@"row:%ld",indexPath.row];
        
    }
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
