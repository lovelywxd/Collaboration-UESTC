//
//  homeViewController.h
//  MyBookRecycle
//
//  Created by 苏丽荣 on 16/6/17.
//  Copyright © 2016年 苏丽荣. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "baseViewController.h"

//@interface homeViewController : baseViewController
@interface homeViewController : UIViewController 
//@property (strong, nonatomic) IBOutlet UINavigationBar *navigationBar;
@end
